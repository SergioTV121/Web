$(document).ready(()=>{
    $("#modificar").validetta({
      onValid:(e)=>{
        alert("Validado")
     }
   });
 });