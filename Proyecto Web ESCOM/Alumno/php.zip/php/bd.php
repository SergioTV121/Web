<?php
function conectarBD(){
    $servidor="localhost";
    $nombreBD="bd_tt";
    $usuario="root";
    $contrasena="";

    $conexion=mysqli_connect($servidor,$usuario,$contrasena,$nombreBD);
    
    return $conexion;
}
?>